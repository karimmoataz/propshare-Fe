import { View, Text } from 'react-native'
import React from 'react'

const Insights = () => {
  return (
    <View className='bg-[#f7f7fa] h-full'>
      <Text>Insights</Text>
    </View>
  )
}

export default Insights